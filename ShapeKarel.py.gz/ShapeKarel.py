from karel.stanfordkarel import *


def main():
    """Each problem uses a different world (e.g. problem 1 uses world lab01_1.kwld, etc.), so it
    is necessary for us to change the world each time we move from problem to problem.

    Run the ShapeKarel configuration for problem 3.
    """

    problem_3()


def problem_3():
    """
    Your solution to problem 3 goes here. Feel free to rename this function if you like!
    Don't forget to remove the pass statement!

    pre-condition: Your pre-condition description goes here!
    post-condition: Your post-condition description goes here!
    """

    pass



####### DO NOT EDIT CODE BELOW THIS LINE ########

if __name__ == '__main__':
    execute_karel_task(main)
